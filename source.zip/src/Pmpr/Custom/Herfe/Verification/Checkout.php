<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453f4145f6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Checkout extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('woocommerce_after_checkout_validation', [$this, 'wuygsimmccoqgykm'], 10, 2); } public function wuygsimmccoqgykm($icwicymcioeyeyek, $ueeagokqmgisgauy) { if ($this->uwkmaywceaaaigwo()->issssuygyewuaswa()->ksgkoukcicwkkaum() && $this->keisyeayucoausym()) { $cgceoyqmmwumqyqa = $this->uwkmaywceaaaigwo()->wikusamwomuogoau(); $this->caokeucsksukesyo()->euekiyuksecoccus()->add($ueeagokqmgisgauy, 'not_verified', sprintf(__('Your account not verified, please %s first.', PR__CST__HERFE), $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->yuawgssgauywkiia(__('verify your account', PR__CST__HERFE), $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uogsaoywmawqwmcc($cgceoyqmmwumqyqa->quiocgkecyewioqa(self::eewamesyyeqqgswo), $cgceoyqmmwumqyqa->aoqkwiysueqqwigk())))); } return $ueeagokqmgisgauy; } }
