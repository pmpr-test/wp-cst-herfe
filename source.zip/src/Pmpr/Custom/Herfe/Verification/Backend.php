<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd84acaec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Backend extends Common { }
