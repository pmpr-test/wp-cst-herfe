<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04d1961b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Backend extends Common { }
