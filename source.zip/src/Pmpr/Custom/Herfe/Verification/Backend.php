<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839b9a9fd3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Backend extends Common { }
