<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c40e4bf8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x61\x73\163\x77\x6f\162\x64\137\x72\x65\x73\x65\164", [$this, "\x61\x6f\x69\x6f\167\x67\155\x69\x77\165\x71\x6b\x69\163\x75\x71"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
