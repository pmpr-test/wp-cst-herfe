<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec172355e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\141\163\x73\167\157\x72\144\137\x72\x65\163\x65\x74", [$this, "\x61\x6f\151\x6f\x77\x67\155\151\167\165\161\x6b\151\x73\x75\x71"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
