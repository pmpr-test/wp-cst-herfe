<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716bebbd22a0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Verification; class Registration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x61\163\163\x77\x6f\162\144\x5f\x72\145\x73\x65\x74", [$this, "\141\x6f\151\157\x77\x67\x6d\151\x77\x75\x71\153\151\163\x75\x71"], 10, 2); } public function aoiowgmiwuqkisuq($mkucggyaiaukqoce) { $this->kwsaiaucmouiaaya($mkucggyaiaukqoce); } }
