<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d1691ed2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Interfaces\Constants; class Visual extends AbstractVisualAuditory { public function __construct() { $this->slug = Constants::yyigwaqioecwemiw; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\126\x69\163\x75\141\x6c", PR__CST__HERFE); } }
