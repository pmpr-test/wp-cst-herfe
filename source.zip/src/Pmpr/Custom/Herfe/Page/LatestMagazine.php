<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86f72704             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\x74\145\163\164\x2d\x6d\141\147\x61\172\x69\x6e\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\164\x65\x73\x74\x20\115\141\x67\141\x7a\151\156\x65", PR__CST__HERFE); } }
