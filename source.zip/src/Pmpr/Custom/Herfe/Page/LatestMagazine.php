<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716dfcfbad04             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\154\141\164\x65\x73\164\x2d\155\x61\147\141\172\x69\156\x65")->gswweykyogmsyawy(__("\x4c\141\164\145\163\x74\40\115\x61\x67\x61\x7a\x69\x6e\145", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
