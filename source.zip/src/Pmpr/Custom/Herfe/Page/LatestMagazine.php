<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae0a3cc6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; class LatestMagazine extends Page { public function __construct() { $this->slug = "\154\x61\164\x65\163\164\x2d\x6d\141\x67\x61\x7a\x69\x6e\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\141\x74\x65\163\164\x20\115\x61\147\x61\172\151\156\x65", PR__CST__HERFE); } }
