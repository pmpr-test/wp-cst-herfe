<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b4daa8f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; class LatestMagazine extends Page { public function __construct() { $this->slug = "\154\141\164\x65\163\x74\55\x6d\141\147\x61\x7a\151\x6e\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x4c\x61\x74\145\163\164\x20\x4d\141\147\x61\172\151\156\x65", PR__CST__HERFE); } }
