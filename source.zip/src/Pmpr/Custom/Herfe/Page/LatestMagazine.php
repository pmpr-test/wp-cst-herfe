<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670530517c0dd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; class LatestMagazine extends Page { public function __construct() { $this->slug = "\154\141\164\145\x73\164\55\x6d\x61\x67\x61\x7a\x69\x6e\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\x61\x74\x65\x73\x74\40\115\141\x67\x61\x7a\x69\x6e\x65", PR__CST__HERFE); } }
