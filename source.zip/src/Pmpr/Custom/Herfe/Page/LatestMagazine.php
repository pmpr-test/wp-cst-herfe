<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b38fc35e81e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x6c\x61\x74\x65\163\164\x2d\x6d\141\147\141\x7a\151\x6e\x65")->gswweykyogmsyawy(__("\x4c\141\x74\x65\x73\x74\x20\115\x61\147\x61\x7a\x69\x6e\145", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
