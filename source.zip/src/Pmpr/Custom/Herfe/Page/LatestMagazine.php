<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b39013cb8b7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\154\141\164\x65\x73\x74\x2d\155\x61\147\x61\x7a\151\156\145")->gswweykyogmsyawy(__("\x4c\141\x74\145\x73\164\40\115\x61\x67\x61\172\x69\156\x65", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
