<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d1691ed2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; class LatestMagazine extends Page { public function __construct() { $this->slug = "\x6c\x61\164\145\163\164\x2d\155\x61\147\x61\172\151\156\x65"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\x61\164\x65\163\164\x20\x4d\141\147\x61\172\x69\x6e\x65", PR__CST__HERFE); } }
