<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c40e4bf8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\154\x61\x74\x65\x73\x74\x2d\x6d\x61\x67\141\172\151\x6e\x65")->gswweykyogmsyawy(__("\114\141\x74\145\x73\x74\x20\x4d\141\x67\141\x7a\x69\156\x65", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
