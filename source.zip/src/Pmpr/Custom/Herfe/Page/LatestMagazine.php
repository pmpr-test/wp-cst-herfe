<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; class LatestMagazine extends Common { public function __construct() { $this->slug = "\154\141\164\145\163\x74\55\155\x61\x67\x61\172\x69\156\145"; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\114\x61\164\145\x73\x74\x20\115\x61\x67\141\172\151\x6e\x65", PR__CST__HERFE); } }
