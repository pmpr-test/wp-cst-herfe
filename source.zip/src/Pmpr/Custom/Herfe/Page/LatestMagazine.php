<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Herfe\Setting; class LatestMagazine extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x6c\141\164\145\163\x74\55\x6d\x61\x67\x61\x7a\x69\x6e\x65")->gswweykyogmsyawy(__("\114\x61\164\145\x73\x74\x20\x4d\x61\x67\141\172\x69\156\x65", PR__CST__HERFE))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::ouosmmwowoocgiei)); } }
