<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670530517c0dd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Interfaces\Constants; class Auditory extends AbstractVisualAuditory { public function __construct() { $this->slug = Constants::gcwcqmwwgiqsaame; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\165\144\151\x74\157\x72\x79", PR__CST__HERFE); } }
