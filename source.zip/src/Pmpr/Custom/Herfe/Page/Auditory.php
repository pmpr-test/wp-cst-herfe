<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Page; use Pmpr\Common\Foundation\Interfaces\Constants; class Auditory extends AbstractVisualAuditory { public function __construct() { $this->slug = Constants::gcwcqmwwgiqsaame; $this->parent = VisualAuditory::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\x75\144\x69\164\x6f\162\171", PR__CST__HERFE); } }
