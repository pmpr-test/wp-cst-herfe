<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\160\162\x68\150\163\x75\142\x77\x70\x63\157\x6f\153\151\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\165\142\163\143\162\x69\160\164\151\x6f\156\137\143\150\145\x63\x6b\x5f\141\x63\x63\145\163\163\x5f\x72\x65\163\165\154\164", [$this, "\145\151\x6f\147\157\153\165\x65\153\163\147\155\x6f\x6f\171\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto ceiwqkyquikcemmo; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto uycesqqkoeamocgm; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto sqmoqymckwsogsqg; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); sqmoqymckwsogsqg: uycesqqkoeamocgm: ceiwqkyquikcemmo: return $gwykaiwqgaycyggs; } }
