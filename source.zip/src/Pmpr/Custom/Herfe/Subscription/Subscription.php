<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\162\150\150\163\x75\x62\167\160\143\157\x6f\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\163\x75\x62\x73\143\162\x69\x70\x74\151\157\x6e\x5f\143\150\145\x63\153\137\141\x63\x63\x65\163\163\137\162\145\163\x75\x6c\x74", [$this, "\x65\151\x6f\x67\157\153\x75\145\153\163\147\x6d\157\x6f\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qogqewiwmwiwskgm; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto qiaqsassksqiuyae; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto cecuyayqoioasumi; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); cecuyayqoioasumi: qiaqsassksqiuyae: qogqewiwmwiwskgm: return $gwykaiwqgaycyggs; } }
