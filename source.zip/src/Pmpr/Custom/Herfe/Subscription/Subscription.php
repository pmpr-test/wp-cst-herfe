<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b4daa8f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; use Pmpr\Custom\Herfe\Setting; class Subscription extends Container { const msiioyqimogkgcqs = "\160\x72\150\x68\x73\165\142\x77\x70\x63\157\x6f\x6b\151\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\x62\x73\143\162\x69\160\164\151\157\x6e\137\x63\150\x65\x63\153\x5f\141\143\143\145\x73\x73\x5f\x72\x65\x73\x75\x6c\x74", [$this, "\x65\151\157\x67\157\x6b\x75\x65\153\163\x67\x6d\x6f\x6f\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius)) { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if (!$eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); } } } return $gwykaiwqgaycyggs; } }
