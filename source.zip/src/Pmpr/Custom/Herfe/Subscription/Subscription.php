<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec172355e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Setting; class Subscription extends Common { const msiioyqimogkgcqs = "\x70\162\150\150\163\x75\142\x77\160\x63\157\x6f\x6b\x69\145"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\142\x73\143\162\151\x70\x74\x69\x6f\x6e\137\x63\150\x65\x63\x6b\x5f\141\x63\x63\145\x73\163\x5f\162\145\x73\165\154\164", [$this, "\145\x69\x6f\x67\x6f\153\165\x65\x6b\x73\x67\x6d\x6f\x6f\171\x6d"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!(!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius))) { goto qogqewiwmwiwskgm; } if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { goto qiaqsassksqiuyae; } $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if ($eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { goto cecuyayqoioasumi; } $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); cecuyayqoioasumi: qiaqsassksqiuyae: qogqewiwmwiwskgm: return $gwykaiwqgaycyggs; } }
