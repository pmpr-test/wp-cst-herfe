<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716dfcfbad04             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; use Pmpr\Custom\Herfe\Setting; class Subscription extends Container { const msiioyqimogkgcqs = "\160\162\150\x68\x73\165\142\x77\160\143\157\157\x6b\151\x65"; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x73\x75\x62\163\143\162\x69\x70\x74\151\157\x6e\x5f\x63\150\x65\143\153\x5f\141\x63\x63\x65\x73\163\x5f\162\x65\163\x75\154\164", [$this, "\145\151\157\x67\x6f\153\x75\x65\x6b\x73\x67\155\x6f\x6f\x79\155"]); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius)) { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if (!$eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); } } } return $gwykaiwqgaycyggs; } }
