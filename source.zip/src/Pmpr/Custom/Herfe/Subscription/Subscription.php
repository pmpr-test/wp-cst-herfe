<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d850d159             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; use Pmpr\Custom\Herfe\Setting; class Subscription extends Container { const msiioyqimogkgcqs = 'prhhsubwpcookie'; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('subscription_check_access_result', [$this, 'eiogokueksgmooym']); } public function eiogokueksgmooym($gwykaiwqgaycyggs) { if (!$gwykaiwqgaycyggs && $this->weysguygiseoukqw(Setting::ogicqksguosumius)) { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->cukiusasccucgwqc(Constants::mswoacegomcucaik)) { $eiicaiwgqkgsekce = $this->caokeucsksukesyo()->giiecckwoyiawoyy(); if (!$eiicaiwgqkgsekce->aukgyiaewiccooqw(self::msiioyqimogkgcqs)) { $gwykaiwqgaycyggs = true; $eiicaiwgqkgsekce->ycasmmgsmaaumweg(self::msiioyqimogkgcqs, 1, 5); } } } return $gwykaiwqgaycyggs; } }
