<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc702a2e039             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Custom\Herfe\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); Magazine::symcgieuakksimmu(); EnglishArticle::symcgieuakksimmu(); } }
