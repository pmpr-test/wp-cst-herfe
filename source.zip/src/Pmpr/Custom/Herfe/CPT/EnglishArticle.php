<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\x6e\x67\x6c\151\x73\150\x2d\141\x72\164\151\143\x6c\145\163")->muuwuqssqkaieqge(__("\x45\156\147\154\x69\163\x68\40\101\x72\x74\x69\x63\x6c\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\x67\154\151\x73\x68\x20\101\162\164\151\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\x68\151\x63\157\156\x73\55\141\x64\155\x69\156\x2d\x70\x6f\x73\x74"); } }
