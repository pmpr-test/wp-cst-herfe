<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c40e4bf8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\x65\x6e\x67\154\151\163\x68\x2d\x61\x72\164\151\x63\x6c\145\163")->muuwuqssqkaieqge(__("\105\156\147\154\151\x73\x68\40\101\162\x74\x69\x63\154\145\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\147\x6c\x69\163\150\40\101\162\x74\x69\x63\154\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\x61\163\150\x69\143\x6f\x6e\163\55\x61\144\x6d\x69\156\x2d\x70\x6f\163\164"); } }
