<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\x6e\x67\154\151\x73\150\55\141\162\164\151\x63\154\x65\163")->muuwuqssqkaieqge(__("\105\x6e\x67\154\151\x73\x68\x20\x41\x72\164\151\x63\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\147\x6c\x69\163\150\40\x41\162\x74\151\143\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\x73\x68\151\143\157\x6e\163\55\x61\144\x6d\x69\x6e\x2d\x70\157\x73\x74"); } }
