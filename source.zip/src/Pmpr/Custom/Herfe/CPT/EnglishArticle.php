<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716dfcfbad04             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\156\147\x6c\151\163\150\55\141\162\164\x69\x63\154\x65\163")->muuwuqssqkaieqge(__("\x45\x6e\x67\x6c\x69\163\x68\x20\x41\162\164\151\143\154\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\x67\154\151\163\x68\40\101\x72\164\151\x63\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\x68\x69\x63\x6f\x6e\x73\55\141\144\x6d\x69\x6e\55\160\x6f\163\x74"); } }
