<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c489919             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\x6e\147\x6c\151\x73\150\55\x61\x72\x74\x69\x63\154\145\x73")->muuwuqssqkaieqge(__("\x45\156\x67\x6c\x69\163\x68\40\x41\x72\164\151\x63\154\x65\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\x6e\x67\154\x69\x73\150\x20\x41\162\x74\151\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\x73\150\151\x63\x6f\x6e\163\x2d\x61\x64\155\x69\156\55\x70\x6f\x73\x74"); } }
