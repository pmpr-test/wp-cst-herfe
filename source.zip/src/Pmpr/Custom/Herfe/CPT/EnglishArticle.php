<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ae0a3cc6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\x6e\x67\x6c\151\163\x68\x2d\141\x72\164\151\143\154\145\163")->muuwuqssqkaieqge(__("\x45\156\147\x6c\x69\x73\150\40\101\x72\164\x69\143\x6c\145\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\147\x6c\x69\163\x68\x20\101\162\164\x69\x63\154\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\x61\x73\150\151\x63\x6f\x6e\x73\55\141\144\155\151\156\55\160\157\x73\x74"); } }
