<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\156\147\154\151\x73\150\x2d\x61\162\164\x69\x63\x6c\145\x73")->muuwuqssqkaieqge(__("\105\x6e\x67\x6c\151\163\x68\x20\101\x72\x74\x69\143\154\x65\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x45\156\147\154\x69\x73\x68\40\x41\x72\x74\151\x63\154\145", PR__CST__HERFE))->yioesawwewqaigow("\144\141\x73\x68\151\x63\157\x6e\x73\55\x61\x64\x6d\151\156\55\x70\x6f\163\x74"); } }
