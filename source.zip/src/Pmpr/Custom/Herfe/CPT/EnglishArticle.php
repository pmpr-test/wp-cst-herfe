<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86f72704             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\x6e\x67\154\x69\x73\150\55\141\x72\x74\x69\143\154\145\x73")->muuwuqssqkaieqge(__("\105\156\x67\x6c\x69\x73\x68\40\x41\x72\x74\x69\143\154\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\x67\x6c\x69\163\150\x20\x41\162\x74\x69\143\x6c\145", PR__CST__HERFE))->yioesawwewqaigow("\x64\141\163\x68\151\x63\157\156\163\55\141\144\155\x69\x6e\55\x70\157\x73\x74"); } }
