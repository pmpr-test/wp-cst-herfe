<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716bebbd22a0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\156\x67\154\x69\163\x68\x2d\141\162\x74\151\x63\x6c\145\x73")->muuwuqssqkaieqge(__("\x45\x6e\x67\154\x69\x73\x68\40\101\x72\164\151\x63\x6c\145\163", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\147\x6c\x69\163\150\40\101\x72\x74\x69\143\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\163\x68\x69\143\157\156\163\55\x61\x64\155\151\x6e\x2d\x70\x6f\x73\164"); } }
