<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04d1961b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; class EnglishArticle extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([Constants::qescuiwgsyuikume, Constants::yaiacqocwcgmooio, Constants::syooqwmkmsmgwcqw, Constants::goumieeyyqigueiw, Constants::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(Constants::ocsomysosuqaimuc)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, "\145\156\147\x6c\151\x73\150\55\141\x72\x74\x69\143\x6c\x65\163")->muuwuqssqkaieqge(__("\105\156\x67\154\x69\163\150\x20\x41\x72\x74\151\x63\x6c\145\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\105\156\x67\x6c\x69\163\x68\40\101\x72\164\x69\143\x6c\x65", PR__CST__HERFE))->yioesawwewqaigow("\144\141\x73\x68\151\143\157\x6e\163\x2d\141\x64\155\x69\156\55\160\x6f\163\x74"); } }
