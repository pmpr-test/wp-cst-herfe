<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b38fc35e81e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\145\x64\x69\165\155\163", PR__CST__HERFE))->guiaswksukmgageq(__("\115\x65\144\x69\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\151\x75\155\40\x66\157\x72\x20\x6d\x61\x67\141\x7a\x69\156\x65\163", PR__CST__HERFE)); } }
