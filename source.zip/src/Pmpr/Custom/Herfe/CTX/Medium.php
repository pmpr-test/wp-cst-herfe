<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\x65\x64\x69\x75\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\x65\144\x69\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\x65\144\151\x75\155\40\x66\157\162\x20\x6d\141\x67\x61\172\x69\x6e\x65\x73", PR__CST__HERFE)); } }
