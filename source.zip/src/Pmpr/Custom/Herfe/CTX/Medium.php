<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716bebbd22a0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\x65\x64\151\165\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\x65\144\151\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\x64\151\x75\155\40\146\157\x72\40\155\x61\x67\141\172\151\156\x65\x73", PR__CST__HERFE)); } }
