<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670530517c0dd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\x65\144\151\165\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\144\151\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\144\x69\165\x6d\x20\x66\157\162\x20\x6d\x61\147\x61\x7a\151\x6e\x65\163", PR__CST__HERFE)); } }
