<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86f72704             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\144\x69\165\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\x65\144\151\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\x65\x64\151\x75\155\x20\146\157\x72\x20\155\x61\147\x61\x7a\151\156\145\163", PR__CST__HERFE)); } }
