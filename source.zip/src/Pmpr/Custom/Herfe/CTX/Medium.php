<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\x65\x64\151\x75\155\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\145\x64\x69\165\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\145\144\x69\165\155\40\x66\157\162\40\x6d\x61\147\x61\172\x69\x6e\x65\x73", PR__CST__HERFE)); } }
