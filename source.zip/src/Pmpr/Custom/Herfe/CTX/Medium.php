<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b4daa8f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\CTX; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\x75\x6d\x73", PR__CST__HERFE))->guiaswksukmgageq(__("\115\145\x64\151\x75\x6d", PR__CST__HERFE))->gucwmccyimoagwcm(__("\x4d\x65\144\x69\x75\155\40\x66\157\162\x20\x6d\x61\x67\141\172\x69\x6e\145\163", PR__CST__HERFE)); } }
