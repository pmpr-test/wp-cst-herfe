<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec172355e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\115\x65\144\151\165\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\x65\x64\x69\165\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\151\165\155\x20\146\x6f\x72\x20\155\141\147\x61\172\151\x6e\145\x73", PR__CST__HERFE)); } }
