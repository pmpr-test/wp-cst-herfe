<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::wsuusqigsoomsyky)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\165\x6d\163", PR__CST__HERFE))->guiaswksukmgageq(__("\x4d\145\144\x69\x75\155", PR__CST__HERFE))->gucwmccyimoagwcm(__("\115\145\x64\151\165\155\x20\x66\157\162\x20\x6d\x61\x67\141\172\x69\x6e\x65\x73", PR__CST__HERFE)); } }
