<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\164", [$this, "\145\161\x65\143\143\x77\x63\157\x75\151\151\x6b\145\x69\x79\141"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\x74\x61\147\137\151\x6d\141\x67\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\160\x6f\163\x74\137\x74\141\x67\x5f\x74\150\165\x6d\x62\156\x61\x69\154")->gswweykyogmsyawy(__("\x49\x6d\x61\147\145", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(Constants::ocsomysosuqaimuc)->register(); } }
