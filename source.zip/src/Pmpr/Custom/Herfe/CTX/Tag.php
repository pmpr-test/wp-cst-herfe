<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x65\161\x65\143\x63\x77\x63\x6f\x75\x69\x69\x6b\145\151\171\x61"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\164\141\147\137\x69\x6d\141\x67\x65")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\x70\x6f\x73\164\137\164\x61\147\x5f\x74\150\165\155\142\156\x61\151\x6c")->gswweykyogmsyawy(__("\111\155\141\147\x65", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(Constants::ocsomysosuqaimuc)->register(); } }
