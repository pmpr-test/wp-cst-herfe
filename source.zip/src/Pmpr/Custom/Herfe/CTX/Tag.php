<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; class Tag extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\x74", [$this, "\x65\161\x65\x63\x63\167\143\157\165\x69\x69\x6b\x65\x69\x79\141"]); } public function eqeccwcouiikeiya() { $gosmywauqawmcyga = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $gosmywauqawmcyga->scyscgskcwukckyy("\x74\141\147\137\x69\x6d\141\x67\145")->mkksewyosgeumwsa($gosmywauqawmcyga->quaegkgkucwyeiqg("\160\x6f\x73\164\x5f\164\141\147\x5f\164\x68\165\155\142\156\x61\x69\154")->gswweykyogmsyawy(__("\111\x6d\141\147\145", PR__CST__HERFE))->ycueqsmmommygueu())->auoaeeuwaqswggqg(Constants::ocsomysosuqaimuc)->register(); } }
