<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { public function iwiyggkewesgioys() { $kieokceicuuaiuso = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ciugwooasaqcywas(Advertise::kueeagiqseeaeogs, [], Constants::oyaoekcogwkcekcc); $ycuekasamuuasigw = null; if (!$kieokceicuuaiuso) { goto yqagomygmeoecwey; } $ycuekasamuuasigw = array_pop($kieokceicuuaiuso); yqagomygmeoecwey: return $ycuekasamuuasigw; } public function ucgqwmuigscaceuu() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return !$ewgmommeawggyaek->scmcyesmmikkucie(Constants::gewmeskawiqikkoc) && $ewgmommeawggyaek->scmcyesmmikkucie(Advertise::kueeagiqseeaeogs); } }
