<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d92edefab             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Herfe\Container; abstract class Common extends Container { public function iwiyggkewesgioys() { $kieokceicuuaiuso = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ciugwooasaqcywas(Advertise::kueeagiqseeaeogs, [], Constants::oyaoekcogwkcekcc); $ycuekasamuuasigw = null; if ($kieokceicuuaiuso) { $ycuekasamuuasigw = array_pop($kieokceicuuaiuso); } return $ycuekasamuuasigw; } public function ucgqwmuigscaceuu() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return !$ewgmommeawggyaek->scmcyesmmikkucie(Constants::gewmeskawiqikkoc) && $ewgmommeawggyaek->scmcyesmmikkucie(Advertise::kueeagiqseeaeogs); } }
