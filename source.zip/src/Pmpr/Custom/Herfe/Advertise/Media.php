<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d92edefab             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\144\137\141\x74\x74\x61\143\x68\x6d\145\156\164", [$this, "\147\167\x6b\155\x6b\x77\x79\x65\157\x69\145\147\x61\x79\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\x61\x78\137\x71\165\145\162\171\137\141\164\164\141\143\x68\155\145\156\164\163\x5f\141\x72\x67\163", [$this, "\x69\x79\157\x69\151\x65\171\x6f\x6f\x71\x6b\161\x77\x6d\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
