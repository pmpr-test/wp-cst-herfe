<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e04d1961b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\144\137\141\164\x74\x61\x63\x68\x6d\x65\156\x74", [$this, "\147\167\153\x6d\x6b\x77\x79\x65\x6f\151\145\147\141\171\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\x61\x78\137\161\x75\x65\162\x79\x5f\141\x74\164\141\x63\150\x6d\x65\x6e\x74\163\137\141\162\x67\x73", [$this, "\151\x79\x6f\x69\151\x65\x79\x6f\157\161\153\x71\167\155\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
