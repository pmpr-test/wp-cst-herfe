<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716dfcfbad04             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x64\137\141\164\x74\x61\x63\x68\x6d\x65\156\x74", [$this, "\147\167\x6b\x6d\x6b\167\171\x65\157\151\x65\x67\x61\171\143\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\141\170\x5f\x71\165\145\162\171\137\141\164\x74\141\143\x68\x6d\x65\156\x74\x73\x5f\141\162\x67\x73", [$this, "\151\x79\x6f\x69\x69\x65\x79\x6f\x6f\x71\x6b\161\167\x6d\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
