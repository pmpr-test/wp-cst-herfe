<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c40e4bf8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x64\x5f\x61\164\x74\x61\x63\x68\155\145\x6e\x74", [$this, "\x67\167\153\x6d\153\x77\171\x65\x6f\151\x65\x67\141\171\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\141\x78\x5f\161\x75\x65\x72\171\137\x61\x74\x74\x61\143\150\x6d\145\x6e\x74\163\x5f\141\x72\x67\x73", [$this, "\151\171\x6f\x69\151\x65\171\x6f\157\161\x6b\x71\x77\x6d\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
