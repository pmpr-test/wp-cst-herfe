<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x64\137\x61\x74\x74\141\143\150\x6d\x65\x6e\x74", [$this, "\x67\x77\x6b\155\x6b\167\171\x65\x6f\151\145\147\x61\x79\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\x78\x5f\x71\165\x65\162\171\x5f\141\164\164\141\143\150\155\x65\156\164\x73\137\141\162\x67\163", [$this, "\151\171\x6f\x69\151\145\171\157\x6f\161\x6b\161\x77\155\x69\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
