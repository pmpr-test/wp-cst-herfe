<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670530517c0dd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x64\x5f\141\x74\x74\141\x63\150\155\x65\156\x74", [$this, "\147\x77\x6b\155\x6b\167\171\145\x6f\x69\145\x67\141\171\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\152\141\170\x5f\161\165\x65\162\171\137\141\164\164\x61\143\x68\155\145\x6e\164\x73\x5f\x61\162\x67\x73", [$this, "\x69\x79\157\151\x69\x65\x79\x6f\157\x71\x6b\161\x77\x6d\151\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
