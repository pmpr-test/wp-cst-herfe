<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716bebbd22a0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x64\x5f\141\x74\164\x61\x63\150\155\145\x6e\164", [$this, "\147\x77\153\155\153\x77\x79\x65\157\x69\145\x67\x61\171\x63\141"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\152\141\170\x5f\161\165\145\162\x79\x5f\141\x74\x74\141\x63\150\155\x65\x6e\164\163\x5f\x61\x72\x67\x73", [$this, "\x69\x79\157\151\x69\145\x79\x6f\157\x71\x6b\x71\x77\x6d\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
