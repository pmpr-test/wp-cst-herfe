<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b39013cb8b7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\144\137\x61\164\x74\x61\143\x68\x6d\145\156\164", [$this, "\x67\167\x6b\x6d\x6b\167\171\145\157\x69\x65\x67\141\171\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\141\x6a\141\170\x5f\x71\x75\x65\162\171\x5f\x61\164\164\x61\143\150\x6d\x65\156\164\163\x5f\141\162\147\x73", [$this, "\151\171\x6f\151\x69\145\171\157\x6f\x71\x6b\161\167\155\x69\145"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
