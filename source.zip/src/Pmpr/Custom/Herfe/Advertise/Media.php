<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d1691ed2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x64\x5f\x61\x74\x74\x61\143\150\155\x65\x6e\164", [$this, "\147\167\x6b\x6d\153\167\171\x65\157\151\x65\147\x61\171\x63\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x6a\x61\x78\137\x71\x75\145\x72\171\137\x61\164\x74\141\143\x68\155\145\x6e\164\x73\137\x61\x72\x67\163", [$this, "\x69\x79\x6f\151\x69\145\x79\157\157\161\153\161\x77\155\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\75"]]; } return $gqgemcmoicmgaqie; } }
