<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b4daa8f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise; use Pmpr\Common\Foundation\Interfaces\Constants; class Media extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\144\x5f\x61\164\x74\x61\x63\150\x6d\145\156\164", [$this, "\x67\x77\153\x6d\153\167\171\x65\x6f\x69\x65\x67\141\x79\143\x61"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\152\141\170\x5f\x71\x75\x65\x72\x79\x5f\141\164\164\x61\x63\150\x6d\x65\x6e\164\x73\137\x61\x72\147\x73", [$this, "\x69\171\x6f\x69\151\x65\x79\x6f\157\x71\153\161\x77\155\151\x65"]); } public function gwkmkwyeoiegayca($aokagokqyuysuksm) { if ($aigsgikoosikweqa = $this->iwiyggkewesgioys()) { $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ksmqawcowkmegigw(Advertise::kueeagiqseeaeogs, $aigsgikoosikweqa, $aokagokqyuysuksm); } } public function iyoiieyooqkqwmie($gqgemcmoicmgaqie) { if ($this->ucgqwmuigscaceuu()) { $gqgemcmoicmgaqie[Constants::cuoyscoiacswuauq] = [[Constants::ascagqcquwgmygkm => Advertise::kueeagiqseeaeogs, Constants::ciyoccqkiamemcmm => $this->iwiyggkewesgioys(), Constants::ykemsyouoqyoaysg => "\x3d"]]; } return $gqgemcmoicmgaqie; } }
