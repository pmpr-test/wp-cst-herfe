<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453f4145f6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe\Advertise\CPT; use Pmpr\Custom\Herfe\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Advertiser::symcgieuakksimmu(); Gallery::symcgieuakksimmu(); Event::symcgieuakksimmu(); } }
