<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77d4d8a3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const meuwgemwasqmoywm = "\x68\141\163\x68\165\162\x65\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . Constants::woicooamkeqiaemo; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
