<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517508112d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const meuwgemwasqmoywm = "\x68\x61\163\150\x75\x72\x65\x5f"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . Constants::woicooamkeqiaemo; }
