<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd84acaec             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Container extends BaseClass { const meuwgemwasqmoywm = "\x68\x61\x73\150\165\x72\145\137"; const ykuiiemcsgauwaya = self::meuwgemwasqmoywm . Constants::woicooamkeqiaemo; }
