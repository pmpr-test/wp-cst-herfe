<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0698e15a             |
    |_______________________________________|
*/
 use Pmpr\Custom\Herfe\Herfe; Herfe::symcgieuakksimmu();
