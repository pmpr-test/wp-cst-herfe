<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c8548502fe             |
    |_______________________________________|
*/
 use Pmpr\Custom\Herfe\Herfe; Herfe::symcgieuakksimmu();
